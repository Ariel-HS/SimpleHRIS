// src/auth/strategies/jwt.strategy.ts
import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor() {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET || 'my-secret-key',
    });
  }

  async validate(payload: { sub: string; email: string }) {
    console.log("PASS D")
    console.log(payload)
    console.log(payload.sub)
    console.log(payload.email)
    return { userId: payload.sub, email: payload.email };
  }
}
